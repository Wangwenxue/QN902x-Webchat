Project                 Content
prj_ancsc               Example for apple notification center service client(NC).
prj_anps                Example for alert notification service.
prj_bass                Example for battery service.
prj_blps                Example for blood pressure sensor.
prj_broadcaster         Example for Broadcaster role.
prj_client              Example for GATT client role.
prj_controller_mode     Example for controller mode.
prj_cscp                Example for Cycling speed and cadence service.
prj_eaci_controller     Example for easy ACI controller.
prj_eaci_host           Example for easy ACI Host.
prj_eapi                Example for easy API.
prj_fcc_ce              Example for fcc/ce test.
prj_findt               Example for find me target.
prj_glps                Example for glucose sensor.
prj_hids                Example for HID service.
prj_hrps                Example for heart rate sensor.            
prj_htpt                Example for health thermometer.
prj_observer            Example for Observer role.
prj_ota                 Example for OTA service.
prj_pasps               Example for phone alert status service.
prj_proxr               Example for proximity reporter.
prj_qpps                Example for QPP service.
prj_rscps               Example for running speed and cadence service.
prj_scpps               Example for scan server.
prj_simple_peripheral   Example for simple peripheral.
prj_tips                Example for time server.


