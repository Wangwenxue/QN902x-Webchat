Project         Content
acmp            Example for ACMP (Analog Comparator)
adc             Example for ADC (Analog to Digital Converter
dma             Example for DMA (Direct Memory Access)
gpio            Example for GPIO (General Purpose Input/Output)
i2c             Example for I2C (Inter-Integrated Circuit)
pwm             Example for PWM (Pulse-Width Modulation)
rtc             Example for RTC (Real Time Control)
spi             Example for SPI (Serial Peripheral Interface)
uart            Example for UART (Universal Asynchronous Receiver/Transmitter)
serialflash     Example for serial flash
sleep           Example for sleep
wdt             Example for watch dog
timer           Example for timer
